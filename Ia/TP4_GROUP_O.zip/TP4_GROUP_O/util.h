
int place_boat(int x,int y, Map* mapa, Boat* barco);

Map*build_automatic_map(int map_size,int n_boats);
